// screen size

const SCREEN_W = 1920;
const SCREEN_H = 1080;

// coordinates of the screen center
const SCREEN_CX = SCREEN_W/2;
const SCREEN_CY = SCREEN_H/2;

// game states
const STATE_INIT = 2;
const STATE_RESTART = 3;
const STATE_PLAY = 4;
const STATE_GAMEOVER = 5;

// sprites
const PLAYER = 0;

// ---------------------------------------------------------------------------------
// Global Variables
// ---------------------------------------------------------------------------------

// current state
let state = STATE_INIT;
let cursors;
let move;
let winText;
let loseText;
let countdownText;
let countdown;
let countdownTimer = 30;

// ---------------------------------------------------------------------------------
// Main Scene
// ---------------------------------------------------------------------------------

class MainScene extends Phaser.Scene
{
    constructor(){
        super({key: 'SceneMain'});
    }

    /**
     * Loads all assets.
     */
    preload() {
        this.load.image('imgBack', 'Assets/img_back.png');
        this.load.image('imgPlayer', 'Assets/img_player.png');
        this.load.image('imgBillboard', 'Assets/img_billboards.png');
        this.load.image('imgCars', 'Assets/img_cars.png');
        this.load.image('imgHills', 'Assets/img_hills.png');
        this.load.image('imgSigns', 'Assets/img_signs.png');
        this.load.image('imgSky', 'Assets/img_sky.png');
        this.load.image('imgTrees', 'Assets/img_trees.png');
        this.load.image('imgTrucks', 'Assets/img_trucks.png');
    }


    /**
     * Creates all objects.
     */
    create() {
        // backgrounds
        this.sprBack = this.add.image(SCREEN_CX, SCREEN_CY, 'imgBack');



        // array of sprites that will be "manually" drawn on a rendering texture
        // (that's why they must be invisible after creation)
        this.sprites = [
            this.add.image(0, 300, 'imgPlayer').setVisible(false)
        ]

        // instances

        //Timer creation
        countdownText = this.add.text(100, 100, countdownTimer, {fontSize: 100})

        loseText = this.add.text(730, 300, "YOU LOSE!", {fontSize: 100})
            .visible = false


        this.countdown = this.time.addEvent({
            delay: 1000,
            callback: function() {
                if (countdownTimer >= 0) {
                    countdownTimer--;
                }
            },
            callbackScope: this,
            loop: true,
        });

        this.countdown.paused = false;

        this.circuit = new Circuit(this);
        this.player = new Player(this);
        this.camera = new Camera(this);
        this.settings = new Settings(this);

        // listener to pause game
        this.input.keyboard.on('keydown-P', function(){
            this.settings.txtPause.text = "[P] Resume";
            this.scene.pause();
            this.scene.launch('ScenePause');
        }, this);

        // listener on resume event
        this.events.on('resume', function(){
            this.settings.show();
        }, this);

        cursors = this.input.keyboard.createCursorKeys();
        move = 0.02;

    }


    /**
     * Main Game Loop
     */
    update(time, delta){

        //Counter update
        countdownText.setText("TIME: " + countdownTimer);


        //Counter State change on zero
        if(countdownTimer <= 0)
        {
            winText = this.add.text(730, 300, "YOU WIN!", {fontSize: 100})
                .visible = true
            countdownText.visible = false
            state = STATE_GAMEOVER
        }

        if (cursors.left.isDown)
        {
            this.player.x -= 0.02;
        }
        else if (cursors.right.isDown)
        {
            this.player.x += 0.02;
        }

        if (this.player.x >= 1)
        {
            this.player.x = 1;
        } else if (this.player.x <= -1)
        {
            this.player.x = -1;
        }

        switch(state){
            case STATE_INIT:
                this.camera.init();
                this.player.init();

                state = STATE_RESTART;
                break;

            case STATE_RESTART:
                this.circuit.create();
                this.player.restart();

                state = STATE_PLAY;
                break;

            case STATE_PLAY:
                // duration of the time period
                let dt = Math.min(1, delta/1000);

                this.player.update(dt);
                this.camera.update();

                this.circuit.render3D();
                break;

            case STATE_GAMEOVER:
                break;

        }

    }
}

// ---------------------------------------------------------------------------------
// Pause Scene
// ---------------------------------------------------------------------------------

class PauseScene extends Phaser.Scene
{
    constructor(){
        super({key: 'ScenePause'});
    }

    create(){
        // listener to resume game
        this.input.keyboard.on('keydown-P', function(){
            this.scene.resume('SceneMain');
            this.scene.stop();
        }, this);
    }
}

// ---------------------------------------------------------------------------------
// Initializing Phaser Game
// ---------------------------------------------------------------------------------

// game configuration
let config = {
    type: Phaser.AUTO,
    width: SCREEN_W,
    height: SCREEN_H,

    scale: {
        mode: Phaser.Scale.FIT,
        autoCenter: Phaser.Scale.CENTER_BOTH,
    },

    scene: [MainScene, PauseScene]
};

// game instance
let game = new Phaser.Game(config);