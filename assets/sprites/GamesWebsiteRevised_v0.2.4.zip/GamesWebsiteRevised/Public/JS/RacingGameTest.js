let config = {
    type: Phaser.AUTO,
    scale: {
        parent: 'phaserGameTest',
        mode: Phaser.Scale.FIT,
        autoCenter: Phaser.Scale.CENTER_BOTH,
        width: 800,
        height: 600
    },
    physics: {
        default: 'matter',
        matter: {
            debug: false,
            gravity: {
                x: 0,
                y: 0
            }
        }
    },
    scene: {
        preload: preload,
        create: create,
        update: update
    }
};

var car;
var cursors;
var lap;
var point1;
var point2;
var point3;

var game = new Phaser.Game(config);

function preload ()
{
    this.load.image('track1', 'Assets/Track1.png');
    this.load.image('car', 'Assets/Player Car.png');
}

function create ()
{
    this.add.tileSprite(400, 300, 800, 600, 'track1');

    car = this.matter.add.image(370, 160, 'car');
    car.setAngle(0);
    car.setFrictionAir(0.5);
    car.setMass(10);

    point1 = this.add.image(150, 300, 'point1')
    point2 = this.add.image(400, 420, 'point2')
    point3 = this.add.image(650, 300, 'point3')
    lap = this.add.image(330, 170, 'lap')

    this.matter.world.setBounds(0, 0, 800, 600);

    cursors = this.input.keyboard.createCursorKeys();
}

function update ()
{

    var speed = 0.25;
    var angle = { x: speed * Math.cos(car.body.angle), y: speed * Math.sin(car.body.angle) };
    var angle = { x: 0, y: 0 };

    if (cursors.left.isDown)
    {

        Phaser.Physics.Matter.Matter.Body.setAngularVelocity(car.body, -0.05);
        car.angle -= 0.2;
    }
    else if (cursors.right.isDown)
    {

        Phaser.Physics.Matter.Matter.Body.setAngularVelocity(car.body, 0.05);
        car.angle += 0.2;
    }

    if (cursors.up.isDown)
    {
        car.thrust(-0.06);
    }
    else if (cursors.down.isDown)
    {
        car.thrustBack(-0.04);
    }
}